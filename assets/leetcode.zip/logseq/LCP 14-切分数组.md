<p>给定一个整数数组 <code>nums</code> ，小李想将 <code>nums</code> 切割成若干个非空子数组，使得每个子数组最左边的数和最右边的数的最大公约数大于 1 。为了减少他的工作量，请求出最少可以切成多少个子数组。</p>

<p><strong>示例 1：</strong></p>

<blockquote>
<p>输入：<code>nums = [2,3,3,2,3,3]</code></p>

<p>输出：<code>2</code></p>

<p>解释：最优切割为 [2,3,3,2] 和 [3,3] 。第一个子数组头尾数字的最大公约数为 2 ，第二个子数组头尾数字的最大公约数为 3 。</p>
</blockquote>

<p><strong>示例 2：</strong></p>

<blockquote>
<p>输入：<code>nums = [2,3,5,7]</code></p>

<p>输出：<code>4</code></p>

<p>解释：只有一种可行的切割：[2], [3], [5], [7]</p>
</blockquote>

<p><strong>限制：</strong></p>

<ul>
	<li><code>1 &lt;= nums.length &lt;= 10^5</code></li>
	<li><code>2 &lt;= nums[i] &lt;= 10^6</code></li>
</ul>
