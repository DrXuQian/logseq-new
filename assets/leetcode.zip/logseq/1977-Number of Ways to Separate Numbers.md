<p>你写下了若干 <strong>正整数</strong>&nbsp;，并将它们连接成了一个字符串&nbsp;<code>num</code>&nbsp;。但是你忘记给这些数字之间加逗号了。你只记得这一列数字是 <strong>非递减</strong>&nbsp;的且&nbsp;<strong>没有</strong> 任何数字有前导 0 。</p>

<p>请你返回有多少种可能的 <strong>正整数数组</strong>&nbsp;可以得到字符串&nbsp;<code>num</code>&nbsp;。由于答案可能很大，将结果对 <code>10<sup>9</sup> + 7</code>&nbsp;<b>取余</b>&nbsp;后返回。</p>

<p>&nbsp;</p>

<p><strong>示例 1：</strong></p>

<pre><b>输入：</b>num = "327"
<b>输出：</b>2
<b>解释：</b>以下为可能的方案：
3, 27
327
</pre>

<p><strong>示例 2：</strong></p>

<pre><b>输入：</b>num = "094"
<b>输出：</b>0
<b>解释：</b>不能有数字有前导 0 ，且所有数字均为正数。
</pre>

<p><strong>示例 3：</strong></p>

<pre><b>输入：</b>num = "0"
<b>输出：</b>0
<strong>解释：</strong>不能有数字有前导 0 ，且所有数字均为正数。
</pre>

<p><strong>示例 4：</strong></p>

<pre><b>输入：</b>num = "9999999999999"
<b>输出：</b>101
</pre>

<p>&nbsp;</p>

<p><strong>提示：</strong></p>

<ul>
	<li><code>1 &lt;= num.length &lt;= 3500</code></li>
	<li><code>num</code>&nbsp;只含有数字&nbsp;<code>'0'</code> 到&nbsp;<code>'9'</code>&nbsp;。</li>
</ul>
